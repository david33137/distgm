# GmailCreator Hidemium - Deployment Guide

## 🚀 Easy Deployment to Any Machine

### Features
- ✅ **No hardcoded paths** - Works on any machine
- ✅ **Dynamic path resolution** - Automatically detects project location
- ✅ **Cross-platform compatible** - Windows, Linux, macOS
- ✅ **Automatic dependency installer** - One-click setup

### Quick Setup

#### Option 1: Automatic Setup (Recommended)

**Windows:**
```bash
# Double-click or run in Command Prompt
setup.bat
```

**Linux/macOS:**
```bash
chmod +x setup.sh
./setup.sh
```

**Cross-platform:**
```bash
python install.py
```

#### Option 2: Manual Setup

1. **Extract/Clone project to any folder**:
   ```
   C:\MyProjects\GmailCreator\
   D:\Tools\GmailCreator\
   /home/user/GmailCreator/
   ```

2. **Install Python dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

3. **Setup proxy file**:
   ```
   proxy.txt (in project root)
   ```

4. **Run the application**:
   ```bash
   python gmail_creator_ui.py
   ```

### System Requirements

- **Python 3.7+** (Python 3.8+ recommended)
- **Internet connection** for downloading packages
- **GUI support** (tkinter) for the user interface

### Dependencies

#### Required:
- `requests>=2.25.1` - HTTP requests
- `filelock>=3.8.0` - Thread-safe file operations

#### Optional:
- `python-dotenv>=0.19.0` - Environment variables (ProxyIPv6)
- `psutil>=5.8.0` - System monitoring (ProxyIPv6)

#### Built-in (no installation needed):
- `tkinter` - GUI framework (included with Python)
- `threading` - Multi-threading support
- `os`, `sys`, `time` - Standard library

### Directory Structure
```
GmailCreator/
├── config.py              # Auto-detects paths
├── gmail_creator_ui.py     # Main UI
├── requirements.txt        # Dependencies list
├── install.py             # Cross-platform installer
├── setup.bat              # Windows setup script
├── setup.sh               # Linux/macOS setup script
├── modules/               # Core modules
├── javascript/            # JS files (auto-detected)
└── proxy.txt             # Proxy list
```

### Installation Files

| File | Purpose | Platform |
|------|---------|----------|
| `requirements.txt` | Pip dependencies list | All |
| `install.py` | Interactive installer | All |
| `setup.bat` | One-click Windows setup | Windows |
| `setup.sh` | One-click Unix setup | Linux/macOS |

### Path Configuration
All paths are now **automatically detected**:

- **Project Root**: `os.path.dirname(os.path.abspath(__file__))`
- **JavaScript Path**: `os.path.join(PROJECT_ROOT, "javascript")`
- **All modules**: Use relative imports

### Troubleshooting

#### tkinter Issues (Linux):
```bash
# Ubuntu/Debian
sudo apt-get install python3-tk

# CentOS/RHEL
sudo yum install tkinter

# Fedora
sudo dnf install python3-tkinter
```

#### Permission Issues (Linux/macOS):
```bash
chmod +x setup.sh
```

#### Python Not Found:
- Make sure Python 3.7+ is installed
- Add Python to your system PATH
- Use `python3` instead of `python` on Unix systems

### No Manual Configuration Required! 🎉

Just extract and run setup - the application will automatically:
- Install all dependencies
- Detect project location
- Find JavaScript files
- Load configurations
- Start working immediately

---
*Updated: August 30, 2025 - Complete Deployment System*
