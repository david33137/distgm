-- Usage: lua54.exe rotate_ipv6.lua <port> <new_ipv6> <interface_name> <log_file>

local args = {...}
if #args < 4 then
    print("[ERROR] Usage: lua54.exe rotate_ipv6.lua <port> <new_ipv6> <interface_name> <log_file>")
    os.exit(1)
end

local port        = args[1]
local new_ipv6    = args[2]
local interface   = args[3]
local log_file    = args[4]

-- Hàm ghi log
local function log(message)
    local f = io.open(log_file, "a")
    if f then
        f:write(os.date("%Y-%m-%d %H:%M:%S") .. " [LUA] " .. message .. "\n")
        f:close()
    end
end

-- Hàm chạy lệnh hệ thống và trả kết quả
local function exec(cmd)
    local handle = io.popen(cmd .. " 2>&1") -- Chuyển hướng stderr sang stdout
    local result = handle:read("*a")
    local success, exit, code = handle:close()
    return result, success, code
end

-- Kiểm tra trạng thái interface
local function check_interface()
    local result, success, code = exec('netsh interface show interface name="' .. interface .. '"')
    if not success or code ~= 0 then
        log("[ERROR] Interface " .. interface .. " is not available: " .. result)
        print("[ERROR] Interface " .. interface .. " is not available: " .. result)
        os.exit(1)
    end
    if not result:match("Connected") then
        log("[ERROR] Interface " .. interface .. " is not connected")
        print("[ERROR] Interface " .. interface .. " is not connected")
        os.exit(1)
    end
    return true
end

-- Kiểm tra interface trước khi thực hiện
check_interface()

-- Gán IPv6 mới
log("Adding new IPv6: " .. new_ipv6 .. " on interface " .. interface .. " for port " .. port)
local add_result, success, code = exec('netsh interface ipv6 add address "' .. interface .. '" ' .. new_ipv6)
if not success or code ~= 0 then
    log("[ERROR] Failed to add IPv6 " .. new_ipv6 .. ": " .. add_result)
    print("[ERROR] Failed to add IPv6 " .. new_ipv6 .. ": " .. add_result)
    os.exit(1)
end

-- In ra kết quả cho Python
log("IPv6 rotated on port " .. port .. " -> " .. new_ipv6)
print("[SUCCESS] IPv6 rotated on port " .. port .. " -> " .. new_ipv6)
os.exit(0)