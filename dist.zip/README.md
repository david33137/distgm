# Gmail Creator Hidemium

Ứng dụng tự động tạo tài khoản Gmail sử dụng Hidemium Browser và Proxy rotation.

## 🚀 Tính năng chính

- **Multi-threading**: Tạo nhiều tài khoản Gmail đồng thời
- **Proxy rotation**: Sử dụng proxy để tránh bị block
- **UI hiện đại**: Giao diện 2 tab với real-time logs
- **Configuration management**: Lưu/load cấu hình dễ dàng
- **JSON-based settings**: Cấu hình linh hoạt với JSON

## 📁 Cấu trúc project

```
GmailCreatorHidemium/
├── gmail_creator_ui.py          # Giao diện chính (2 tabs)
├── main_multi_thread.py         # Engine chính tạo Gmail
├── config.py                    # Cấu hình mặc định
├── api_endpoint.json           # Cấu hình API endpoints
├── configs/                     # Thư mục lưu configurations
│   ├── default.json
│   ├── fast_batch.json
│   └── mac_test.json
├── modules/                     # Các modules chính
│   ├── multi_thread_creator.py  # Multi-thread creator
│   ├── gmail_creator.py         # Gmail creation logic
│   ├── hidemium_api.py         # Hidemium API integration
│   ├── proxy_manager.py        # Proxy management
│   ├── browser_controller.py   # Browser control
│   ├── page_handlers.py        # Page handling
│   └── js_handler.py           # JavaScript execution
├── javascript/                  # JavaScript files
├── proxy.txt                   # Danh sách proxy
└── used_proxies.txt           # Proxy đã sử dụng
```

## 🔧 Cài đặt và sử dụng

### 1. Chạy ứng dụng
```bash
python gmail_creator_ui.py
```

### 2. Sử dụng giao diện
- **Tab Configuration**: Cấu hình tất cả thông số
- **Tab Execution & Logs**: Khởi chạy và giám sát real-time

### 3. Quản lý cấu hình
- Lưu cấu hình: Nhập tên và click "💾 Save"
- Load cấu hình: Double-click vào danh sách hoặc nhập tên và click "📂 Load"
- Xóa cấu hình: Chọn tên và click "🗑 Delete"

## ⚙️ Cấu hình

### Thông số cơ bản
- **Gmail accounts**: Số lượng account cần tạo
- **Max threads**: Số thread đồng thời
- **Delay**: Thời gian chờ giữa các lần tạo

### Timeout settings
- **Total timeout**: Thời gian tối đa cho mỗi account
- **Profile timeout**: Timeout tạo profile
- **Element timeout**: Timeout tương tác browser

### Profile configuration
- Cấu hình JSON chi tiết cho thông tin profile
- Hỗ trợ validation JSON real-time

## 📊 Logs và Monitoring

- **Real-time logs** từ tất cả modules
- **Color-coded messages**: INFO, SUCCESS, WARNING, ERROR, SYSTEM
- **Auto-scroll**: Tự động cuộn theo logs mới
- **Save/Clear logs**: Lưu logs ra file hoặc xóa

## 🔍 Troubleshooting

### Lỗi thường gặp
1. **Proxy connection**: Kiểm tra file `proxy.txt`
2. **Hidemium API**: Kiểm tra `api_endpoint.json`
3. **Browser timeout**: Tăng timeout settings

### Debug
- Xem logs trong tab "Execution & Logs"
- Kiểm tra console output
- Verify JSON configuration

## 📝 Các file quan trọng

- `gmail_creator_ui.py`: UI chính
- `main_multi_thread.py`: Logic tạo Gmail
- `config.py`: Cấu hình mặc định
- `api_endpoint.json`: API endpoints
- `modules/`: Tất cả modules core

## 🚦 Workflow

1. **Configuration**: Setup trong tab Configuration
2. **Validation**: Validate JSON config
3. **Execution**: Switch sang tab Execution
4. **Monitoring**: Theo dõi logs real-time
5. **Results**: Check kết quả trong logs

---

**Phiên bản**: 3.0 (Clean version)
**Tác giả**: Gmail Creator Team
**Cập nhật**: August 2025
